<!DOCTYPE html>
<html lang="ja">
<head>
<link rel="stylesheet" href="<?php echo e(asset('/css/header.css')); ?>">
</head>
<body>
    <header class="header">

        <a class="title" href="top">ジョギング管理アプリケーション</a>
        <div class=menu>
            <p class="top"><a href="top">Top</a></p>
            <p class="date"><a href="data_regist">データ入力</a></p>
            <p class="rank"><a href="#">ランキング</a></p>
            <p class="hikaku"><a href="#">データ比較</a></p>
            <p class="mypage"><a href="mypage">Mypage</a></p>
            <div class="logout" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
        </div>


    </header>
<?php $__env->startSection('content'); ?>
    
            <?php echo $__env->yieldContent('content'); ?>

<img src="<?php echo e(asset('storage/img/back.png')); ?>" alt="背景" class="back">
</body>
</html><?php /**PATH C:\Users\itou\Desktop\2024_3\jogging-management\jogging\resources\views/layouts/user.blade.php ENDPATH**/ ?>