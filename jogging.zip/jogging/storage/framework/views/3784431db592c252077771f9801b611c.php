<?php $__env->startSection('title','Index'); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/css/datal.css')); ?>">
<?php $__env->startSection('content'); ?>
<h1>ジョギングデータ</h1>
<div class="layout">
    <div class="data_1">
        <?php if($data->status = 0): ?>
        <p class="status1"style= "background-color:aquamarine; text-align: center; border-radius: 5px;padding: 20px;">室内</p>
        <?php else: ?>
        <p class="status2" style="background-color:aqua;text-align: center; border-radius: 10px;padding: 5px;">室外</p>
        <?php endif; ?>
        <div>
            <div class="data">
                <p>日付：<?php echo e($data->run_day); ?></p>
                <p>走行距離：<?php echo e($data->distance); ?>km</p>
                <P>走行時間：<?php echo e($data->time); ?>時間</P>
            </div>
        </div>
</div>
<div class="img">
    <img src="<?php echo e(asset('storage/img/'.$data->img_pass)); ?>" alt="ジョギング画像" class="j_img" >
</div>
</div>
<a class="back_a"href="top">戻る</a>
<a class="update"href="top">編集する</a>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\itou\Desktop\2024_3\jogging-management\jogging\resources\views/joging/datal.blade.php ENDPATH**/ ?>