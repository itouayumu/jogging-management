<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <link rel="stylesheet" href="<?php echo e(asset('/css/log_reg.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/css/header.css')); ?>">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">

   
    <link rel="stylesheet" href="<?php echo e(asset('/css/+a.css')); ?>">
</head>
<body>
    <div id="app">
        <header class="header">
                <a href="<?php echo e(url('/')); ?>" class="title">
                   ジョギング管理
                </a>
                <div class=menu>
               <p class="nav-link"> <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a></p>
               <p class="nav-link"> <a class="nav-link" href="<?php echo e(route('register')); ?>">新規登録</a></p>
                </div>
        </header>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <img src="<?php echo e(asset('storage/img/back.png')); ?>" alt="背景" class="back">
</body>
</html>
<?php /**PATH C:\Users\itou\Desktop\2024_3\jogging-management\jogging\resources\views/layouts/app.blade.php ENDPATH**/ ?>