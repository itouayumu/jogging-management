<?php $__env->startSection('title','Index'); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->startSection('content'); ?>
<div class="data_1">
    <p>走行距離：<?php echo e($data->distance); ?></p>
    <P>走行時間：<?php echo e($data->time); ?></P>
</div>
<img src="<?php echo e(asset('storage/img/'.$data->img_pass)); ?>" alt="商品画像" >

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\itou\Desktop\2024_3\jogging-management\jogging\resources\views/joging/sab.blade.php ENDPATH**/ ?>